Hello <?php echo e($user->name); ?>

Thank you for create an account . Please verify email  using this link
<?php echo e(route('verify',$user->verification_token)); ?>