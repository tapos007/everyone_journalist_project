<?php

return [

    'pagination_limit' => env('pagination_limit', 10),
    'mail_api_key' => env('MAILCHIMP_API_KEY', '0f6aaf6b7c0437360569c2e30d1f8d01-us15'),
];

?>